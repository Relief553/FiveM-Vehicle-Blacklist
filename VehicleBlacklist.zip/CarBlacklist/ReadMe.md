--					 ===================================
--					 Copyright © 2022 Relief Development
--					 ===================================

Instructions - Installation
1. Unzip from "Vehicle Blacklist"
2. Place "CarBlacklist" inside you resources folder
3. Add "start CarBlacklist" to you server.cfg // Without the ""
4. Restart Server or Start Scripts Via Console

Instructions - Assistance
1. Join the discord // https://discord.gg/etagEJsawf
2. Create a support ticket
3. Wait for assistance

--					 =============================================================
--					 This Script was made by Aidan2køld#6611 DBA Relief Development
--					 =============================================================