fx_version 'cerulean'
games { 'rdr3', 'gta5' }

author 'Relief Development'
description 'Vehicle Blacklist Script'
version '1.0.0'

client_scripts {
	"client/vehicles-client.lua",
	"client/general-client.lua"
}